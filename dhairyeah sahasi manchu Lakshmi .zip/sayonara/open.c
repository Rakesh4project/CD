#include<stdio.h>

int main(){
printf("he");
scanf("");
printf("he");
scanf("");
scanf("");

return 0;
}